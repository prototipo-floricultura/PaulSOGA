# Prototipo de orientación tecnológica para floricultura

Herramienta académica asociada al TFE **Propuesta de solución digital inicial basada en tecnologías de Industria 4.0 para empresas floricultoras de la Sabana de Cundinamarca**, de Paul Albert Soltys Galvis.

## Abrir la herramienta

Abra `dist/index.html` en un navegador actual. No requiere instalación, registro, servidor ni conexión a Internet para evaluar las condiciones. La misma herramienta puede servirse como un sitio web estático.

Si recibió el paquete descargable, descomprímalo y abra `Herramienta_orientacion_floricultura.html`.

## Qué hace

- Recoge 19 condiciones agregadas, con estados **Sí**, **No** y **No comprobado**.
- Recorre cinco fases y localiza la primera condición pendiente en la secuencia obligatoria.
- Señala prerrequisitos pendientes aunque se hayan declarado capacidades posteriores.
- Activa calidad asistida y trazabilidad ampliada solo cuando su necesidad se ha confirmado.
- Explica la recomendación, las condiciones pendientes, los productos que deben verificarse y su trazabilidad con los hallazgos H y requisitos R del TFE.
- Permite imprimir el resultado o guardarlo en PDF mediante el diálogo de impresión del navegador.

## Qué no hace

No es un clasificador predictivo ni un modelo de aprendizaje automático. No calcula una puntuación de madurez, no verifica documentos automáticamente y no certifica empresas. No incorpora sensores, una base de datos empresarial, un modelo de visión artificial entrenado ni una red blockchain. Las referencias a esas capacidades describen condiciones de la propuesta que deberían comprobarse en un piloto posterior.

Las pruebas incluidas verifican la lógica del programa, no su efectividad empresarial. Los tres casos de ejemplo son ficticios y se identifican como demostrativos; no representan participantes ni resultados adicionales del trabajo de campo.

## Regla de decisión

1. Comprobar la fase 0, **Alineación**: alcance, gobierno del dato, línea base y recursos preliminares.
2. Si está declarada completa, comprobar la fase 1, **Captura básica**: formatos, desconexión, mantenimiento, seguridad, aprendizaje y eventos por lote.
3. Si las anteriores están declaradas completas, comprobar la fase 2, **Nube y tableros**.
4. Considerar la fase 3, **Calidad asistida**, solo si existe un caso visual confirmado.
5. Considerar la fase 4, **Trazabilidad ampliada**, solo si existe una necesidad confirmada; no depende de activar inteligencia artificial cuando esta no sea necesaria.

Una condición marcada como **No** o **No comprobado** impide declarar completa la fase correspondiente. Las fases posteriores pueden figurar como declaradas, pero con prerrequisitos pendientes. No se asignan pesos, probabilidades o umbrales aprendidos de las entrevistas.

## Vinculación con el TFE

El trabajo cualitativo fundamenta 15 hallazgos y 15 requisitos. La herramienta agrupa estos requisitos en 19 condiciones de orientación para cinco fases de adopción. No convierte las ocho personas consultadas en ocho empresas clasificadas. La correspondencia operativa se encuentra en `docs/trazabilidad.csv` y en la tabla desplegable de la propia herramienta.

La lógica del motor se conserva respecto de la versión incorporada al Word corregido el 8 de septiembre de 2026. La versión 1.1.0 adapta el acceso independiente, la denominación visible, el diseño de la interfaz y la documentación para su entrega como software. La navegación por fases y los contadores de respuestas no añaden una escala de madurez ni cambian las reglas de decisión.

## Privacidad

La evaluación se realiza en memoria, dentro del navegador. El programa no contiene conexiones de envío de respuestas, analítica de uso, cookies de aplicación ni persistencia local. No solicita nombres, correos, identificadores de empresas o archivos. Al cerrar o recargar la página se pierden las respuestas. La impresión o descarga que decida realizar el usuario crea un archivo local bajo su control.

En la versión alojada, el proveedor de alojamiento puede tratar los datos técnicos normales de una conexión web; ello es distinto del contenido de las respuestas, que la aplicación no envía. Este repositorio no contiene entrevistas, consentimientos, firmas, grabaciones ni bases de participantes.

## Comprobación técnica

Con Node.js 18 o posterior, ejecute desde la raíz del repositorio:

```text
node tests/reglas.test.cjs
node scripts/verificar-entrega.cjs
```

Los resultados se documentan en `docs/PRUEBAS.md`. El programa funciona sin Node.js para la persona que solamente desea usar el archivo HTML.

## Estructura

```text
dist/index.html                  Herramienta web autocontenida
dist/LEEME.html                  Manual legible en el navegador
dist/Herramienta_TFE_Floricultura.zip   Entrega descargable
docs/MANUAL_USUARIO.md           Manual de uso
docs/NOTA_TECNICA.md             Arquitectura y límites
docs/trazabilidad.csv            Condiciones y correspondencia H/R
docs/PRUEBAS.md                  Evidencia de pruebas
tests/reglas.test.cjs            Pruebas del motor de decisión
scripts/empaquetar.cjs           Generación de archivos de entrega
scripts/verificar-entrega.cjs    Integridad y coherencia del paquete
scripts/servidor.cjs             Vista previa local opcional
package.json                    Metadatos y comandos de desarrollo
```

## Uso académico y autoría

Proyecto académico de Paul Albert Soltys Galvis. Se utilizó asistencia de inteligencia artificial para programación, edición y comprobaciones técnicas. Ello no constituye entrenamiento de un modelo predictivo ni generación de datos empíricos. La interpretación del estudio y la decisión de uso corresponden al autor y a los responsables de la evaluación.

La disponibilidad del código para revisión no equivale a una licencia general de software libre. No se incorpora una licencia abierta sin una decisión expresa del titular del trabajo.

**Versión:** 1.1.0 · **Fecha de entrega del software:** 10 de septiembre de 2026.
