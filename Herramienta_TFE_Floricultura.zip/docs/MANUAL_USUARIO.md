# Manual de uso

## 1. Acceso

Abra la herramienta en línea o descomprima la descarga y haga doble clic en `Herramienta_orientacion_floricultura.html`. Active JavaScript en un navegador actual. No necesita crear una cuenta para usar el archivo descargado.

## 2. Preparación

Responda con apoyo de una persona que conozca los procesos y las evidencias de la empresa. No introduzca datos personales. La aplicación no recibe documentos ni comprueba su autenticidad.

## 3. Diligenciamiento

Use las cinco fases de la navegación lateral —superior en pantallas pequeñas— o los botones **Anterior** y **Siguiente fase**. Cambiar de fase no borra las respuestas. Los contadores indican cuántas condiciones tienen una respuesta Sí o No; no representan cumplimiento ni madurez.

Para cada una de las 19 condiciones seleccione:

- **Sí:** existe evidencia suficiente y revisable de la condición.
- **No:** se confirmó que la condición no está satisfecha.
- **No comprobado:** no se dispone de información suficiente para decidir.

El estado inicial es **No comprobado** en todas las condiciones. Revise también las preguntas que activan las fases opcionales: necesidad de calidad visual asistida y necesidad de trazabilidad ampliada.

## 4. Generar y leer el resultado

Seleccione **Generar orientación**. El resultado indica la primera fase pendiente, las condiciones que la detienen, los productos o evidencias necesarios antes de avanzar y las incoherencias entre prerrequisitos y capacidades declaradas.

Puede generar la orientación sin terminar todas las fases: las condiciones no revisadas siguen como **No comprobado**. Si cambia una respuesta después de obtener el resultado, aparece un aviso de actualización pendiente; seleccione nuevamente **Generar orientación**.

Los rótulos H01–H15 y R identifican la relación con los hallazgos y requisitos del TFE. No son puntuaciones ni resultados producidos por inteligencia artificial. Una fase «declarada cumplida» no equivale a una certificación: debe corroborarse su evidencia.

## 5. Casos demostrativos

Abra **Explorar con un ejemplo ficticio** y elija uno de los tres casos:

- **Base manual:** orienta a la fase 0 porque faltan condiciones de alineación.
- **Datos listos, sin IA:** declara completas las fases obligatorias; no activa módulos avanzados que no se necesitan.
- **Trazabilidad sin registros base:** vuelve a la fase 1 y advierte la dependencia incumplida.

Los ejemplos son ficticios. Puede cambiar cualquier respuesta después de cargarlos. No use estos ejemplos como resultados de una empresa real.

## 6. Imprimir o guardar en PDF

Seleccione **Imprimir resultado**. El navegador vuelve a calcular la orientación con las respuestas actuales y abre su diálogo de impresión. Puede elegir una impresora o **Guardar como PDF**. Revise el contenido antes de compartirlo.

## 7. Reiniciar

Seleccione **Limpiar** para volver al estado inicial. Recargar o cerrar la página también elimina las respuestas de la sesión. La aplicación no conserva un historial de evaluaciones.

## 8. Interpretación responsable

No utilice el resultado como única base para invertir, certificar, contratar o evaluar el desempeño de personas. La recomendación sirve para organizar una revisión de condiciones y evidencias. La validación empresarial, las pruebas de integración y la evaluación de utilidad quedan fuera de las pruebas funcionales incluidas.
