# Nota técnica

## Producto implementado

Aplicación web estática, autocontenida, escrita en HTML, CSS y JavaScript. El archivo `dist/index.html` incluye la presentación, el catálogo de condiciones, el motor determinista y los controladores de interfaz. Puede ejecutarse desde disco o desde un alojamiento estático. No requiere servicios de datos ni credenciales de API.

## Entradas, proceso y salidas

| Elemento | Implementación |
| --- | --- |
| Entradas | 19 condiciones agregadas; tres estados permitidos por condición. |
| Normalización | Una respuesta ausente o ajena al catálogo se interpreta como `no_comprobado`. |
| Núcleo obligatorio | Fases 0, 1 y 2, en ese orden. |
| Módulos condicionados | Fase 3 activada por `visualCase`; fase 4 por `traceabilityNeed`. |
| Decisión | Primera fase activada con criterios que no sean `si`. |
| Explicación | Condiciones pendientes, evidencias de salida, avisos y correspondencia H/R. |
| Persistencia | Ninguna; únicamente memoria de la página. |
| Comunicación | No se transmiten respuestas ni se solicitan servicios externos. |

## Relación entre análisis cualitativo y software

Los requisitos ya establecidos en el TFE se operacionalizan en condiciones verificables y dependencias de adopción. El motor no aprende de las 200 respuestas, no vuelve a codificar las 64 unidades de sentido y no estima una distribución sectorial. La clasificación cualitativa del corpus y la orientación por reglas de este software son operaciones diferentes.

La tabla `docs/trazabilidad.csv` se genera directamente desde el catálogo que ejecuta el programa. Así, las condiciones publicadas, sus fases y sus referencias coinciden con el código entregado.

## Criterios de seguridad y privacidad

- Política CSP restrictiva: no se permiten conexiones salientes del programa.
- Sin scripts, hojas de estilo, tipografías o imágenes de terceros.
- Sin formularios enviados al servidor, archivos subidos, analítica o cookies de aplicación.
- El texto insertado en resultados pasa por escape HTML.
- No se distribuyen documentos de campo ni datos de participantes.
- El servidor de vista previa atiende solamente archivos de `dist` y solo desde la interfaz local.

## Integración opcional con agentes

Cuando el navegador expone la interfaz WebMCP compatible, se registra una operación de orientación sobre las mismas condiciones de la interfaz. Valida las entradas y actualiza el mismo resultado visible. En navegadores sin esa capacidad, la aplicación conserva íntegramente su funcionamiento manual. Esta integración no implica que el motor use inteligencia artificial para decidir.

## Límites de la comprobación

Las pruebas automatizadas verifican secuencia, dependencias, fases opcionales, consistencia de referencias, integridad de archivos y ausencia de conexiones de envío en el programa. No acreditan validez diagnóstica, precisión predictiva, mejoras de productividad ni aceptación por empresas o evaluadores académicos.

## Reproducibilidad

No existen dependencias externas de ejecución. Los scripts de desarrollo usan módulos incluidos en Node.js. El paquete descargable y el inventario de integridad se generan desde el mismo archivo que se publica. El archivo `SHA256SUMS.txt` permite identificar los contenidos de la entrega sin incluir credenciales ni material de campo.
