# Comprobación funcional

La batería reproducible `tests/reglas.test.cjs` ejecuta directamente el motor de reglas incrustado en la herramienta. No se utiliza una copia distinta del algoritmo.

## Casos comprobados

1. Respuestas faltantes: orientación a fase 0.
2. Capacidades de nube con captura pendiente: prioridad de fase 1.
3. Fases posteriores declaradas con prerrequisitos incompletos: estado bloqueado.
4. Recursos preliminares: no se exige un TCO completo para la entrada a fase 0.
5. Ausencia de caso visual: la IA no se activa.
6. Caso visual confirmado con controles pendientes: orientación a fase 3.
7. Todas las fases activadas y declaradas completas: sin condición activada pendiente.
8. Trazabilidad ampliada sin eventos base: advertencia y retorno a fase 1.
9. Trazabilidad ampliada sin necesidad de IA: fase 4 permitida después del núcleo.
10. Catálogo de estados y referencias H/R consistente.
11. Cobertura de los 15 hallazgos y 15 requisitos documentados.
12. Aplicación autocontenida y sin canales de envío de respuestas.

## Alcance

Estas pruebas son verificaciones de software. No son evaluaciones realizadas por empresas, pruebas de exactitud diagnóstica, evidencia de productividad ni aprobación académica.

La verificación adicional `scripts/verificar-entrega.cjs` revisa la sintaxis de JavaScript, los archivos documentales y la tabla de 19 condiciones. La integridad del ZIP se comprueba mediante lectura de todos sus archivos y sus sumas SHA-256.

## Compatibilidad opcional WebMCP

El programa incorpora una operación opcional para navegadores con WebMCP. No se presenta como verificada en un contexto nativo WebMCP si ese contexto no está disponible. Esta limitación no afecta a los controles manuales ni al motor de orientación.

## Repetir las pruebas

Desde la raíz del código fuente, con Node.js 18 o posterior:

```text
node tests/reglas.test.cjs
node scripts/verificar-entrega.cjs
```

La salida debe indicar 12 pruebas aprobadas y cero fallidas, seguida de la comprobación documental. Cualquier error detiene el proceso con un código de salida no satisfactorio.
