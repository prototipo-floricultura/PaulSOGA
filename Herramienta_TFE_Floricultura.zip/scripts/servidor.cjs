"use strict";
const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");
const base = path.resolve(__dirname, "../dist");
const types = {".html":"text/html; charset=utf-8", ".zip":"application/zip", ".txt":"text/plain; charset=utf-8", ".csv":"text/csv; charset=utf-8", ".json":"application/json"};
const server = http.createServer((req, res) => {
  if (!['GET','HEAD'].includes(req.method)) {res.writeHead(405);res.end();return;}
  try {
    const relative = decodeURIComponent(new URL(req.url,"http://localhost").pathname).replace(/^\/+/, "") || "index.html";
    const target = path.resolve(base, relative);
    if (!target.startsWith(base + path.sep)) {res.writeHead(403);res.end();return;}
    fs.readFile(target, (err, data) => {
      if (err) {res.writeHead(404);res.end("No encontrado");return;}
      res.writeHead(200, {"Content-Type":types[path.extname(target)] || "application/octet-stream", "Cache-Control":"no-store", "X-Content-Type-Options":"nosniff"});
      res.end(req.method === 'HEAD' ? undefined : data);
    });
  } catch {res.writeHead(400);res.end();}
});
server.listen(0,"127.0.0.1",()=>console.log("Local URL: http://127.0.0.1:"+server.address().port));
process.on("SIGINT",()=>server.close(()=>process.exit(0)));
