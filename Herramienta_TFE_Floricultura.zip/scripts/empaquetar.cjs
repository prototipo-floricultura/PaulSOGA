"use strict";
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");
const crypto = require("node:crypto");
const root = path.resolve(__dirname,"..");
const html = fs.readFileSync(path.join(root,"dist/index.html"),"utf8");
const scope = {};
vm.createContext(scope);
vm.runInContext(html.match(/<script id="rules-source">([\s\S]*?)<\/script>/)[1],scope);
const model = scope.ClasificadorTFE;
const q = value => '"'+String(value).replaceAll('"','""')+'"';
const rows = [["condicion_id","fase","condicion","criterio","referencias_H_R","evidencia_salida"],...Object.entries(model.CRITERIA).map(([id,c])=>[id,c.phase,c.title,c.prompt,c.refs,c.output])];
fs.writeFileSync(path.join(root,"docs/trazabilidad.csv"),'\ufeff'+rows.map(row=>row.map(q).join(',')).join('\r\n')+'\r\n');
const escape = value => value.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;');
function markdownBasic(text){
  let code=false;
  return text.split(/\r?\n/).map(line=>{
    if(line.startsWith('```')){code=!code;return code?'<pre>':'</pre>';}
    if(code)return escape(line)+'\n';
    const h=line.match(/^(#{1,3}) (.*)$/);
    if(h)return '<h'+h[1].length+'>'+escape(h[2])+'</h'+h[1].length+'>';
    if(!line.trim())return '';
    return '<p>'+escape(line).replace(/\*\*(.*?)\*\*/g,'<strong>$1</strong>').replace(/`(.*?)`/g,'<code>$1</code>')+'</p>';
  }).join('\n');
}
const documentation = ['MANUAL_USUARIO.md','NOTA_TECNICA.md','PRUEBAS.md'].map(name=>markdownBasic(fs.readFileSync(path.join(root,'docs',name),'utf8'))).join('<hr>');
const manual='<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Documentación de la herramienta TFE</title><style>html{background:#f2f6f4}body{font:16px/1.65 "Segoe UI",Arial,sans-serif;color:#17392f;max-width:960px;margin:32px auto;padding:32px clamp(20px,5vw,60px);background:#fff;border:1px solid #dce5df;border-radius:16px}a{color:#167451}nav{padding:8px 0 24px;border-bottom:1px solid #dce5df;margin-bottom:30px}h1,h2{line-height:1.25;letter-spacing:-.025em}h1{font:2rem/1.2 Georgia,serif;color:#113c30}pre{overflow:auto;background:#f2f6f4;padding:16px;border-radius:9px}hr{border:0;border-top:1px solid #dce5df;margin:40px 0}code{overflow-wrap:anywhere}@media print{nav{display:none}body{border:0;padding:0;margin:0}}</style></head><body><nav><a href="index.html">← Volver a la herramienta</a></nav>'+documentation+'</body></html>';
fs.writeFileSync(path.join(root,'dist/LEEME.html'),manual);
const files = new Map();
// The standalone and hosted programs have the same source and rules.
files.set('Herramienta_orientacion_floricultura.html',Buffer.from(html));
files.set('index.html',Buffer.from(html));
files.set('dist/index.html',Buffer.from(html));
files.set('dist/LEEME.html',Buffer.from(manual));
files.set('LEEME.html',Buffer.from(manual));
for(const rel of ['README.md','package.json','docs/MANUAL_USUARIO.md','docs/NOTA_TECNICA.md','docs/PRUEBAS.md','docs/trazabilidad.csv','tests/reglas.test.cjs','scripts/empaquetar.cjs','scripts/verificar-entrega.cjs','scripts/servidor.cjs'])files.set(rel,fs.readFileSync(path.join(root,rel)));
const sums=[...files].sort(([a],[b])=>a.localeCompare(b)).map(([name,bytes])=>crypto.createHash('sha256').update(bytes).digest('hex')+'  '+name).join('\n')+'\n';
files.set('SHA256SUMS.txt',Buffer.from(sums));
const table=Array.from({length:256},(_,n)=>{for(let k=0;k<8;k++)n=(n&1)?0xedb88320^(n>>>1):n>>>1;return n>>>0;});
function crc32(bytes){let c=0xffffffff;for(const b of bytes)c=table[(c^b)&255]^(c>>>8);return (c^0xffffffff)>>>0;}
const locals=[],central=[];let offset=0;
for(const [name,bytes] of files){
  const label=Buffer.from(name);const crc=crc32(bytes);
  const header=Buffer.alloc(30);header.writeUInt32LE(0x04034b50,0);header.writeUInt16LE(20,4);header.writeUInt16LE(0x800,6);header.writeUInt32LE(crc,14);header.writeUInt32LE(bytes.length,18);header.writeUInt32LE(bytes.length,22);header.writeUInt16LE(label.length,26);header.writeUInt16LE(((2026-1980)<<9)|(9<<5)|10,12);
  locals.push(header,label,bytes);
  const entry=Buffer.alloc(46);entry.writeUInt32LE(0x02014b50,0);entry.writeUInt16LE(20,4);entry.writeUInt16LE(20,6);entry.writeUInt16LE(0x800,8);entry.writeUInt16LE(((2026-1980)<<9)|(9<<5)|10,14);entry.writeUInt32LE(crc,16);entry.writeUInt32LE(bytes.length,20);entry.writeUInt32LE(bytes.length,24);entry.writeUInt16LE(label.length,28);entry.writeUInt32LE(offset,42);
  central.push(entry,label);offset+=header.length+label.length+bytes.length;
}
const centralBuffer=Buffer.concat(central),end=Buffer.alloc(22);end.writeUInt32LE(0x06054b50,0);end.writeUInt16LE(files.size,8);end.writeUInt16LE(files.size,10);end.writeUInt32LE(centralBuffer.length,12);end.writeUInt32LE(offset,16);
const archive=Buffer.concat([...locals,centralBuffer,end]);
fs.writeFileSync(path.join(root,'dist/Herramienta_TFE_Floricultura.zip'),archive);
fs.writeFileSync(path.join(root,'dist/Herramienta_orientacion_floricultura.html'),html);
fs.writeFileSync(path.join(root,'dist/SHA256SUMS.txt'),sums);
console.log(JSON.stringify({files:files.size,bytes:archive.length,sha256:crypto.createHash('sha256').update(archive).digest('hex')},null,2));
