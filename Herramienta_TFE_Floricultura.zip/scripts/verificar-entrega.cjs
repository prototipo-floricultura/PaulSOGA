"use strict";
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const root=path.resolve(__dirname,'..');
const html=fs.readFileSync(path.join(root,'dist/index.html'),'utf8');
let count=0;
for(const match of html.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/g)){new vm.Script(match[1]);count++;}
if(count!==2)throw new Error('Cantidad inesperada de scripts');
for(const item of ['dist/LEEME.html','docs/MANUAL_USUARIO.md','docs/NOTA_TECNICA.md','docs/PRUEBAS.md','docs/trazabilidad.csv','README.md','tests/reglas.test.cjs']){
  if(!fs.existsSync(path.join(root,item)))throw new Error('Falta '+item);
}
const csv=fs.readFileSync(path.join(root,'docs/trazabilidad.csv'),'utf8');
if(csv.trim().split(/\r?\n/).length!==20)throw new Error('La matriz debe contener 19 condiciones más cabecera');
if(!html.includes('generar_orientacion_tecnologica'))throw new Error('Falta integración opcional');
if(!html.includes('No guarda ni transmite respuestas'))throw new Error('Falta aviso de privacidad');
console.log('PASS: sintaxis, 19 condiciones, documentación, trazabilidad y aviso de privacidad.');
